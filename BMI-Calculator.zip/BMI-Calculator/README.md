# BMI-Calculator
![Frame 284](https://user-images.githubusercontent.com/61702243/96000349-6afded00-0e54-11eb-9db7-652c8a78f7cb.png)
